export const keyUser = 'm8nvn*&hKwcgb^D-D#Hz^5CXfKySpY';
export const keyToken = 'b7a2bdf4-ac40-4012-9635-ff4b7e55eae0';
export const keyRefreshToken = '15c665b7-592f-4b60-b31f-a252579a3bd0';
export const timeBuild = '0fc57d7b-0b51-41ef-8b7e-ed7b7d5dba16';
export const APP_NAME = import.meta.env.VITE_APP_NAME;
export const linkApi = import.meta.env.VITE_URL_API;
export const languages = import.meta.env.VITE_URL_LANGUAGES.split(',');
export const language = import.meta.env.VITE_URL_LANGUAGE;
